import React from "react";
import {
  Breadcrumb,
  BreadcrumbItem,
  Card,
  CardBody,
  CardHeader,
  Media,
} from "reactstrap";
import { Link } from "react-router-dom";

function RenderLeader({ leader }) {
  return (
    <Media tag="li">
      <Media left middle>
        <Media
          object
          src={leader.image}
          alt={leader.name}
          style={{ height: "50px", width: "50px" }}
        />
      </Media>
      <Media body className="ml-5">
        <Media heading>{leader.name}</Media>
        <p>{leader.designation}</p>
        <p>{leader.description}</p>
      </Media>
    </Media>
  );
}

function LeaderList(props) {
  const leaders = props.leaders.map((leader) => {
    return (
      <div className="col-12 mt-2">
        <RenderLeader leader={leader} />
      </div>
    );
  });

  return <Media list>{leaders}</Media>;
}

function AboutUsComponent(props) {
  return (
    <div className="container">
      <div className="row">
        <Breadcrumb>
          <BreadcrumbItem>
            <Link to="/home" style={{ color: "coral" }}>
              Home
            </Link>
          </BreadcrumbItem>
          <BreadcrumbItem active>About Us</BreadcrumbItem>
        </Breadcrumb>
        <div className="col-12">
          <h3>About Us</h3>
          <hr />
        </div>
      </div>
      <div className="row row-content">
        <div className="col-12 col-md-6">
          <h2>Our History</h2>
          <p>
            We started in 2016, as a small restaurant but over the years we have
            grown into best restaurant in the USA by providing delicious and
            tasty dishes included into our cuisine. We have more than 25 types
            of cusines from around the world including chineese, Mexican, Indian
            etc. Covid changes: We are currently running with limited dinein but
            online orders are going normal. We also do catering on requests for
            birthdays and marriages. Safety of our customers is important for us
            and we are 100% dedicated for that.
          </p>
        </div>
        <div className="col-12 col-md-5">
          <Card>
            <CardHeader className="glance">Facts At a Glance</CardHeader>
            <CardBody>
              <dl className="row p-1">
                <dt className="col-6">Started</dt>
                <dd className="col-6">2016</dd>
                <dt className="col-6">Parent Company</dt>
                <dd className="col-6">USA Whole Foods</dd>
                <dt className="col-6">Last Year's Revenue</dt>
                <dd className="col-6">USD 300,000</dd>
                <dt className="col-6">Employees</dt>
                <dd className="col-6">150</dd>
              </dl>
            </CardBody>
          </Card>
        </div>
      </div>
      <div className="row row-content">
        <div className="col-12">
          <h2>Developers</h2>
        </div>
        <LeaderList leaders={props.leaders} />
      </div>
    </div>
  );
}

export default AboutUsComponent;
