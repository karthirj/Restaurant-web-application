import React, { Component } from "react";
import MenuComponent from "./MenuComponent";
import ContactUsComponent from "./ContactComponent";
import DetailsOfDishComponent from "./DishdetailComponent";
import HeaderComponent from "./HeaderComponent";
import FooterComponent from "./FooterComponent";
import HomeComponent from "./HomeComponent";
import AboutUsComponent from "./AboutComponent";
import ReservationComponent from "./ReservationComponent";
import { AvailableDishes } from "../shared/dishes";
import { DishesComments } from "../shared/comments";
import { Founders } from "../shared/leaders";
import { NewPromotions } from "../shared/promotions";
import { Switch, Route, Redirect } from "react-router-dom";

class MainComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      dishes: AvailableDishes,
      promotions: NewPromotions,
      leaders: Founders,
      selectedDish: null,
      comments: DishesComments,
    };
  }

  /*  onDishSelect(dishId) {
		this.setState({selectedDish:dishId});
	}  */

  render() {
    const HomePage = () => {
      return (
        <HomeComponent
          dish={this.state.dishes.filter((dish) => dish.featured)[0]}
          promotion={this.state.promotions.filter((promo) => promo.featured)[0]}
          leader={this.state.leaders.filter((leader) => leader.featured)[0]}
        />
      );
    };

    const DishWithId = ({ match }) => {
      return (
        <DetailsOfDishComponent
          dish={
            this.state.dishes.filter(
              (dish) => dish.id === parseInt(match.params.dishId, 10)
            )[0]
          }
          comments={this.state.comments.filter(
            (comment) => comment.dishId === parseInt(match.params.dishId, 10)
          )}
        />
      );
    };

    const AboutUs = () => {
      return <AboutUsComponent leaders={this.state.leaders} />;
    };

    return (
      <div>
        <HeaderComponent />
        <Switch>
          <Route path="/home" component={HomePage} />
          <Route path="/aboutus" component={AboutUs} />
          <Route
            exact
            path="/menu"
            component={() => <MenuComponent dishes={this.state.dishes} />}
          />
          <Route path="/menu/:dishId" component={DishWithId} />
          <Route exact path="/contactus" component={ContactUsComponent} />
          <Route exact path="/reservation" component={ReservationComponent} />
          <Redirect to="/home" />
        </Switch>

        {/*<Menu dishes={this.state.dishes}
				onClick={(dishId)=> this.onDishSelect(dishId)}/>
			<DishDetail dish={this.state.dishes.filter((dish) => dish.id === this.state.selectedDish)[0]} /> */}

        <FooterComponent />
      </div>
    );
  }
}

export default MainComponent;
