export const AvailableDishes =
    [
        {
        id: 0,
        name:'Pizza',
        image: '/assets/images/pizza.jpg',
        category: 'mains',
        label:'Hot',
        price:'10.59',
        featured: true,
        description:'A pizza which is topped with Onions, Mushrooms, Fontina cheese, grated, Bell peppers and Fresh soft mozzarella cheese.'                    
        },
        {
        id: 1,
        name:'Chicken Biryani',
        image: '/assets/images/chickenbiryani.jpg',
        category: 'mains',
        label:'Hot',
        price:'13.54',
        featured: true,
        description:'Chicken Biryani is a delicious chicken and rice dish with chicken, rice and aromatic layers that are steamed together. All the chicken juices are absorbed by the bottom layer of rice as it cooks, giving it a tender texture and rich flavor, while the top layer of rice turns out to be white and fluffy.'
        },
        {
        id: 2,
        name:'Fruit Salad',
        image: '/assets/images/fruitsalad.jpg',
        category: 'dessert',
        label:'Best',
        price:'8.79',
        featured: false,
        description:'Fruit Salad is a dish which contains various fruits like bananas, grapes, apples, strawberries, pineapples'
        },
        {
        id: 3,
        name:'Special Dosa',
        image: '/assets/images/dosa.jpg',
        category: 'Breakfast',
        label:'Best',
        price:'5.49',
        featured: false,
        description:'A Rice pancake which mainly consists of rice, panner, masala potato and lentils'
        }
    ];