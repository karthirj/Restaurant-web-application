export const NewPromotions = [
  {
    id: 0,
    name: "Weekend Grand Buffet",
    image: "/assets/images/buffet.jpg",
    label: "Best",
    price: "20.45",
    featured: true,
    description:
      "The buffet has delicious four appetizers, eight salads, five main items and six desserts . There are special juices and drinks. All these itmes for $20 per person.",
  },
];
