To run the application developed using reactjs

install npm (node package manager)
install nodejs
install yarn

To start the application
Open cmd in \ReactApplication\restaurant folder then type
yarn start 


To check the source code of components in restaurant/src/Components